import "reflect-metadata";
import { AppDataSource } from "./src/infrastructure/data-source";

AppDataSource.initialize()
  .then(() => {
    console.log("✅ Conexão com o banco de dados bem-sucedida!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Erro ao conectar com o banco:", error);
    process.exit(1);
  });
