import 'dotenv/config'
import bcrypt from 'bcryptjs'
import { AppDataSource } from './src/infrastructure/data-source'
import { User, UserRole } from './src/domain/entities/User'

async function main() {
  await AppDataSource.initialize()
  const repo = AppDataSource.getRepository(User)

  const email = process.env.ADMIN_EMAIL || 'admin@pousada.com'
  const name = process.env.ADMIN_NAME || 'admin'
  const plain = process.env.ADMIN_PASSWORD || 'admin123'

  const exists = await repo.findOne({ where: { email } })
  if (exists) {
    console.log(`⚠️ Já existe usuário com email ${email}. Nada a fazer.`)
    await AppDataSource.destroy()
    return
  }

  const passwordHash = await bcrypt.hash(plain, 10)

  const user = repo.create({
    email,
    name,
    passwordHash,
    role: UserRole.ADMIN,
    twoFactorEnabled: false,
    twoFactorSecret: null,
    passwordResetCode: null,
    passwordResetExpiresAt: null,
  })

  await repo.save(user)
  console.log(`✅ Admin criado: ${email} (senha: ${plain})`)
  await AppDataSource.destroy()
}

main().catch(async (e) => {
  console.error('❌ Erro no seed do admin:', e)
  try { await AppDataSource.destroy() } catch {}
  process.exit(1)
})
